"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateUser = exports.validateLitterReport = void 0;
var zod_1 = require("zod");
// Define schemas
var LitterReportSchema = zod_1.z.object({
    trailheadId: zod_1.z.string(),
    reportTimestamp: zod_1.z.string().refine(function (val) { return !isNaN(Date.parse(val)); }, {
        message: "Invalid ISO 8601 timestamp",
    }),
    reportId: zod_1.z.string(),
    userId: zod_1.z.string(),
    locationDescription: zod_1.z.string().optional(),
    litterStatus: zod_1.z.enum(["reported", "cleaned"]),
    photoS3Path: zod_1.z.string().optional(),
    trailName: zod_1.z.string().optional(),
    notes: zod_1.z.string().optional(),
    expirationTime: zod_1.z.number().optional(),
});
var UserSchema = zod_1.z.object({
    userId: zod_1.z.string(),
    name: zod_1.z.string().optional(),
    email: zod_1.z.string().email().optional(),
    joinDate: zod_1.z.string().refine(function (val) { return !isNaN(Date.parse(val)); }, {
        message: "Invalid ISO 8601 date",
    }).optional(),
});
// Export schemas and validation helpers
var validateLitterReport = function (data) {
    try {
        return LitterReportSchema.parse(data); // Returns validated data if successful
    }
    catch (err) {
        throw new Error("Validation Error: ".concat(err));
    }
};
exports.validateLitterReport = validateLitterReport;
var validateUser = function (data) {
    try {
        return UserSchema.parse(data); // Returns validated data if successful
    }
    catch (err) {
        throw new Error("Validation Error: ".concat(err));
    }
};
exports.validateUser = validateUser;
