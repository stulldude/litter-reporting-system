import { z } from "zod";

// Define schemas
const LitterReportSchema = z.object({
  trailheadId: z.string(),
  reportTimestamp: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Invalid ISO 8601 timestamp",
  }),
  reportId: z.string(),
  userId: z.string(),
  locationDescription: z.string().optional(),
  litterStatus: z.enum(["reported", "cleaned"]),
  photoS3Path: z.string().optional(),
  trailName: z.string().optional(),
  notes: z.string().optional(),
  expirationTime: z.number().optional(),
});

const UserSchema = z.object({
  userId: z.string(),
  name: z.string().optional(),
  email: z.string().email().optional(),
  joinDate: z.string().refine((val) => !isNaN(Date.parse(val)), {
    message: "Invalid ISO 8601 date",
  }).optional(),
});

// Export schemas and validation helpers
export const validateLitterReport = (data: unknown) => {
  try {
    return LitterReportSchema.parse(data); // Returns validated data if successful
  } catch (err) {
    throw new Error(`Validation Error: ${err}`);
  }
};

export const validateUser = (data: unknown) => {
  try {
    return UserSchema.parse(data); // Returns validated data if successful
  } catch (err) {
    throw new Error(`Validation Error: ${err}`);
  }
};
