import { CognitoJwtVerifier } from "@aws-jwt-verify/jwt-verify";

const verifier = CognitoJwtVerifier.create({
    userPoolId: "us-west-2_XXXXXXXXX", // Replace with your User Pool ID
    clientId: "your-client-id",        // Replace with your App Client ID
    tokenUse: "access",                // Use "id" for ID tokens
});

export const handler = async (event) => {
    try {
        const token = event.headers.Authorization.split(" ")[1];
        const payload = await verifier.verify(token);
        console.log("Token is valid. Payload:", payload);

        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Authorized request", user: payload }),
        };
    } catch (err) {
        return {
            statusCode: 403,
            body: JSON.stringify({ message: "Invalid token" }),
        };
    }
};
